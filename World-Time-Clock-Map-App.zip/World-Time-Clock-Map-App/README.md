# jquery-map-with-time-on-hover
World map with time on hovering map specific area using JQuery

1. Just download the file and extract it.<br>
2. Run the index.html file using any browser.<br>
3. Hover any part of the map and will display the local time of that area.<br>
  
<h3> You are done!</h3>

![alt text](https://github.com/hakikz/jquery-map-with-time-on-hover/blob/master/picture-of-map.jpg)
